#include <stdlib.h>
#include <stdio.h>
#include <time.h>


typedef enum trbcol{ black, red}tree_rbCol;

/* Node */

struct node         {
tree_rbCol color;
int info;
struct node *lchild;
struct node *rchild;
struct node *parent; } ;

/* Functions declaration, the description is at the Fr_btr.c file*/
int insert (int);
void RB_insert_fixup(struct node *z);

void Left_Rotate(struct node *x);
void Rigt_Rotateh(struct node *x);


void RB_delete(struct node *z );
void RB_delete_fixup(struct node *x);

struct node* Tree_successor(struct node *nptr);
struct node* Tree_Min(struct node *x);
struct node* Tree_Max(struct node *x);

/*void display (struct node *ptr,int level);*/
void inorderprnt(struct node *x);
void printkMin_file(struct node *x,FILE*);
void printkMin();
void my_func(int arr[], int , int , int , int );


struct node *root;
struct node *nil;

int main ()      {
int i,size,k;
time_t t;

/* the user defines the array size*/
printf("\n Please enter the array size : \n");
scanf("%d",&size);
int *try;
try=(int*)malloc(size*sizeof(int));

/*random numbers itialization of the array*/
srand((unsigned)time(&t));
for (i=0;i<size;i++){
try[i]=rand()%1023;
}
/*the user defines the k*/
printf("\n Please enter k : \n");
scanf("%d",&k);

nil=(struct node*)malloc(sizeof(struct node));
nil->info=-1;
nil->color =black;
root=nil;

my_func(try, k, (size/4), (size/2), (3*size/4));
return 0;          
                 }



