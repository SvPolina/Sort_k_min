#include <stdlib.h>
#include <stdio.h>

typedef enum trbcol{ black, red}tree_rbCol;

struct node         {
tree_rbCol color;
int info;
struct node *lchild;
struct node *rchild;
struct node *parent; } ;

/*insert new node*/
int  insert (int);
/*tree fixup after node insertion*/
void RB_insert_fixup(struct node *z);
/*left rotate*/
void Left_Rotate(struct node *x);
/*right rotate*/
void Rigth_Rotate(struct node *x);
/*returns the node that contains the tree maximum*/
struct node* Tree_Max(struct node *x);
/*returns the node that contains the tree minimum*/
struct node* Tree_Min(struct node *x);
/*returns the node that contains the successor of the given node*/
struct node* Tree_successor(struct node *x);

/*delete node*/
void RB_delete(struct node *z );
/*tree fixup as a resuls of delete node*/
void RB_delete_fixup(struct node *x);
/*inorder print to the standart output*/
void inorderprnt(struct node *x);
void printkMin();
/*inorder print to a given file*/
void printkMin_file(struct node *x,FILE*);
/*function that performs all the procedures required at the asignment-
1- creates a red-black tree with k nodes 
2- inserts a new node only if 
a - The tree has less than k nodes and the key that we would like to insert is not in the tree yet. 
or
b - The tree has alreasy k nodes but the new key is smaller than the tree maximum. At this case we delete the tree maximum and insert the new node.*/
void my_func(int arr[], int k, int n1, int n2, int n3);

struct node *root;
struct node *nil;


/* Returns the minimum of the rb_tree */
struct node* Tree_Min(struct node *x){
while(x->lchild!=nil){
x=x->lchild;}
return (x);}

/* Returns the successor node of the given node */
struct node* Tree_successor(struct node *x){
struct node *ptr=x->rchild;
while(ptr->lchild!=nil)
{ptr=ptr->lchild;}
return ptr;                                  }

/* Returns the maximum of the rb_tree */
struct node* Tree_Max(struct node *x){
while(x->rchild!=nil){
x=x->rchild;           }
return (x);                          }

/*implements the left  rotate algorithm given at the book page 234*/
void Left_Rotate(struct node *x){
struct node *y;

y=x->rchild;         /*set y*/
x->rchild=y->lchild; /*turns y's left subtree into x's right subtree*/

if (y->lchild!=nil){
y->lchild->parent=x; }

y->parent=x->parent; /*links x's parent to y*/

if (x->parent==nil){
root=y;}

else if (x==x->parent->lchild){
x->parent->lchild=y;}

else {x->parent->rchild=y;}

y->lchild=x;        /*put x on y's left*/
x->parent=y;               
                                     }
/*implements the right rotate algorithm which is similar to left rotate with the appropriate exchange of left <-> right*/
void Rigth_Rotate(struct node *x){
struct node *y;

y=x->lchild;
x->lchild=y->rchild;

if (y->rchild!=nil){
y->rchild->parent=x;}

y->parent=x->parent;

if (x->parent==nil){
root=y;}

else if (x==x->parent->rchild){
x->parent->rchild=y;}

else {x->parent->lchild=y;}

y->rchild=x;
x->parent=y;                }


/*implements the RB_insert algorithm given at the book page 236
 If the key is already in the tree the function return 1 and informs the user. 
 and the tree remains unchanged.*/
int insert(int ikey){
struct node *z,*x,*y;

y=nil;
x=root;

while (x!=nil){
     y=x;
     if(ikey<x->info)
          x=x->lchild;
     else if (ikey>x->info)
           x=x->rchild;
     else {/*printf("Duplicate\n");*/return 1;}
                      }
z=(struct node*)malloc(sizeof(struct node));
z->info=ikey;
z->lchild=nil;
z->rchild=nil;
z->color=red;
z->parent=y;

if(y==nil)
   root=z;
else if(z->info < y->info)
        y->lchild=z;
else y->rchild=z;
RB_insert_fixup(z); 

return 0;}


/*implements the RB_insert_fixup algorithm given at the book page 236*/
void RB_insert_fixup(struct node *z)
{struct node *uncle, *par, *grandPar;

while (z->parent->color==red)
    {
    par=z->parent;
    grandPar=par->parent;

    if(par==grandPar->lchild)
    {
     uncle=grandPar->rchild;
     if (uncle->color==red)
     {                       
     par->color=black;       /*case 1 (by book page. 237)*/
     uncle->color=black;     
     grandPar->color=red;    
     z=grandPar;             
     }
    else
    { 
     if (z==par->rchild)
        {
         Left_Rotate(par); /*case 2 (by book page. 237)*/
         z=par;            
        par=z->parent;/* */
         }
     par->color=black;    /*case 3 (by book page. 237)*/
     grandPar->color=red;
     Rigth_Rotate(grandPar);
    }
    } /* same as in if clause with right<->left exchange*/
else 
{  
    if (par==grandPar->rchild)
    {
       uncle=grandPar->lchild;
       if (uncle->color==red)
       {
        par->color=black;
        uncle->color=black;
        grandPar->color=red;
        z=grandPar;
       }
       else
       {
        if (z==par->lchild)
        {
         Rigth_Rotate(par);
         z=par;
         par=z->parent;/**/
        }
         par->color=black;
         grandPar->color=red;
         Left_Rotate(grandPar);
        }
        }}}
root->color=black;
}

void RB_delete(struct node *z){
struct node *y,*x;

if ((z->lchild==nil)||(z->rchild==nil))
    {y=z;}
  else {y=Tree_successor(z);}

if (y->lchild!=nil){x=y->lchild;}
  else {x=y->rchild;}

x->parent=y->parent;

if (y->parent==nil){root=x;}
   else if(y==y->parent->lchild){ y->parent->lchild=x;}
        else {y->parent->rchild=x;}
if (y!=z)
    {z->info=y->info;}
if (y->color==black){RB_delete_fixup(x);}

}
  
void RB_delete_fixup(struct node *x)
{
	struct node *w;

	while ((x!=root )&&(x->color=black))
	{
 	  if( x == x->parent->lchild )
	  {
		w = x->parent->rchild;
		if( w->color == red )
		{
			w->color = black;    /* Case 1, book page 243 */
			x->parent->color = red;
			Left_Rotate(x->parent);
			w = x->parent->rchild; 
		}
		if(w->lchild->color==black && w->rchild->color==black)
		{
			w->color=red;       /* Case 2, book page 243 */
                        x=x->parent;	
		}
		else
		{
			if(w->rchild->color==black)  /* Case 3, book page 243 */
			{
				w->lchild->color=black;
				w->color=red;
				Rigth_Rotate(w);
				w = x->parent->rchild;
			}
			w->color = x->parent->color;  /* Case 1, book page 243 */
			x->parent->color = black;
			w->rchild->color = black;
			Left_Rotate(x->parent);
			x=root;
		}
	  }/*same as in if clause with right<->left exchange*/
	  else 
	  {
	   w = x->parent->lchild;
		if( w->color == red )
		{
			w->color = black;
			x->parent->color = red;
			Rigth_Rotate(x->parent);
			w = x->parent->lchild; 
		}
		if(w->rchild->color==black && w->lchild->color==black)
		{
			w->color=red;
                        x=x->parent;	
		}
		else
		{
			if(w->lchild->color==black)  
			{
				w->rchild->color=black;
				w->color=red;
				Left_Rotate(w);
				w = x->parent->lchild;
			}
			w->color = x->parent->color;  
			x->parent->color = black;
			w->lchild->color = black;
			Rigth_Rotate(x->parent);
			x=root;
		}	
        
	  }
	}
}

void inorderprnt(struct node *x){
if(x!=nil)
{
 inorderprnt(x->lchild);
printf("%d ",x->info);
 inorderprnt(x->rchild);
}
}

/*the same as inorder print , but prints to a file*/
void printkMin_file(struct node *x,FILE* f){
if(x!=nil)
{
 printkMin_file(x->lchild,f);
 fprintf(f,"%d ",x->info);
 printkMin_file(x->rchild,f);
}
}

void printkMin(){inorderprnt(root);}



/*function that performs the main algorithm,  it receves the pointer to the array,k , n1,n2 and n3 */
void my_func(int arr[], int k, int n1, int n2, int n3){
/*-opens the output file to which we write to-*/
FILE *fd_1;
if(!(fd_1=fopen("Output.txt","w")))  {exit(0);}

struct node *max;
int i,c;

int counter=0; /*--counts the acctual number of nodes at the tree--*/

/*--tree inialization with first k nodes. Each key is being inserted only if it is not at the tree yet.--*/
for (i=0;i<k;i++){if((c=insert(arr[i]))==0)counter++;} 

/*-the tree is being changed in accordance with nodes examined up to n1-*/
if (k<(n1-1)){
  for (i=k;i<n1;i++)  {
        max=Tree_Max(root);
    if  (arr[i]<max->info){  
         if (((c=insert(arr[i]))==0)&&(counter==k)){RB_delete(max);} 
         if((c==0)&&(counter<k))counter++;         
         max=Tree_Max(root);       
                          }
                      }
  printf("Check point n1,the num of nodes is %d\n",counter);
  printkMin(); 
  printf("\n"); 
  fprintf(fd_1,"\nCheck point n1,the num of nodes is %d\n",counter);
  printkMin_file(root,fd_1);   
         }
 else  {if (k==(n1-1)){ printf("Check point n1,the num of nodes is %d\n",counter);
                   printkMin();    
                   printf("\n"); 
                    fprintf(fd_1,"\nCheck point n1,the num of nodes is %d\n",counter);
                    printkMin_file(root,fd_1); }
        else{printf("K is larger than n1 \n");
             fprintf(fd_1,"K is larger than n1 \n");n1=k;} }
    
/*-the tree is being changed in accordance with nodes examined up to n2-*/
if (k<(n2-1)){
  for (i=n1;i<n2;i++)  {
        max=Tree_Max(root);
    if  (arr[i]<max->info){      
        /*c=insert(arr[i]); */

        if (((c=insert(arr[i]))==0)&&(counter==k)){RB_delete(max);} 
        if((c==0)&&(counter<k))counter++;
  
        max=Tree_Max(root);       
                          }
                      }
  printf("Check point n2,the num of nodes is %d\n",counter);
  printkMin();     
  printf("\n");  
  fprintf(fd_1,"\nCheck point n2,the num of nodes is %d\n",counter);
  printkMin_file(root,fd_1);}

 else { if (k==(n2-1)){ printf("Check point n2,the num of nodes is %d\n",counter);
                 printkMin();     
                 printf("\n"); 
                 fprintf(fd_1,"\nCheck point n2,the counter is %d\n",counter);
                 printkMin_file(root,fd_1); }
else{printf("K is larger than n2 \n");
      fprintf(fd_1,"K is larger than n2 \n");n2=k;} }
/*-the tree is being changed in accordance with nodes examined up to n3-*/

if ((k<(n3-1))){
  for (i=n2;i<n3;i++)  {
        max=Tree_Max(root);
    if  (arr[i]<max->info){        
         /*c=insert(arr[i]); */
        if (((c=insert(arr[i]))==0)&&(counter==k)){RB_delete(max);} 
        if((c==0)&&(counter<k))counter++;
         
          max=Tree_Max(root);       
                          }
                      }
  printf("Check point n3,the num of nodes is %d\n",counter);
  printkMin();    
  printf("\n");
  fprintf(fd_1,"\nCheck point n3,the num of nodes is %d\n",counter);
  printkMin_file(root,fd_1);
    } 
else { if (k==(n3-1)){ printf("Check point n3,the num of nodes is %d\n",counter);
                 printkMin();     
                 printf("\n");
                 fprintf(fd_1,"\nCheck point n3,the num of nodes is %d\n",counter);
                 printkMin_file(root,fd_1);} 
else{printf("K is larger than n3 \n");
      fprintf(fd_1,"K is larger than n3 \n");} }

fclose(fd_1); 
}

